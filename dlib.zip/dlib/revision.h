#ifndef DLIB_REVISION_H
// Version:  19.0
// Date:     Sat Jun 25 15:03:34 EDT 2016
// Mercurial Revision ID:  48a5f84a0dea
#define DLIB_MAJOR_VERSION  19
#define DLIB_MINOR_VERSION  0
#define DLIB_PATCH_VERSION  0
#endif
